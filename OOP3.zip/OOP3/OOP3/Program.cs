﻿using OOP3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Иван", 25);
            Student s2 = new Student("Игорь", 23);
            Student s3 = new Student("Иван", 22);
            Student s4 = new Student("Игорь", 23);
            Student s5 = new Student("Даша", 23);
            Student s6 = new Student("Лена", 23);

            StudentGroup group1 = new StudentGroup(new System.Collections.Generic.List<Student> { s1, s2, s3 }, 1);
            StudentGroup group2 = new StudentGroup(new System.Collections.Generic.List<Student> { s4, s5, s6 }, 2);

            StudentStream stream = new StudentStream(101);
            stream.AddGroup(group1);
            stream.AddGroup(group2);

            IEnumerator<StudentGroup> enumerator = stream.GetEnumerator();
            while (enumerator.MoveNext())
            {
                StudentGroup currentGroup = enumerator.Current;
                Console.WriteLine($"Group ID: {currentGroup.GetIdGroup()}");
                foreach (Student student in currentGroup)
                {
                    Console.WriteLine($"  {student}");
                }
            }
        }
    }
}
